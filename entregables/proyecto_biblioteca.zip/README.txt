Proyecto académico Biblioteca
Requiere JDK 17+
Desde esta carpeta, en PowerShell:
New-Item -ItemType Directory -Force out
javac -encoding UTF-8 -d out src/biblioteca/*.java
java -cp out biblioteca.Main
Disponibilidad fija sin control horario ni persistencia.
